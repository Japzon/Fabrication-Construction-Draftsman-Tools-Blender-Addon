# Fabrication & Construction Draftsman Tools (Automated)

![Header Image](https://raw.githubusercontent.com/Japzon/Fabrication-Construction-Draftsman-Tools-Automated/main/header.png)

A comprehensive toolkit for native, non-destructive URDF creation and rigging for ROS/Gazebo directly within Blender.

---

## ⚖️ LEGAL PROTECTION & LICENSE

**IMPORTANT: This repository is LEGALLY PROTECTED.**

### Ownership
This software, including all source code, logic, algorithms, UI designs, and documentation, is the exclusive intellectual property of **Japzon**. 

### No Unauthorized Use
*   **Copyright (c) 2026 Japzon.** All rights reserved.
*   **FOOLPROOF PROTECTION**: This work is NOT licensed for public redistribution, sub-licensing, or commercial resale by any third party.
*   **AUTORSHIP**: Any attempt to claim this work as your own or to license it under a different name is a violation of international copyright law.
*   **RESTRICTIONS**: You may not sell, lease, or distribute "modified" versions of this tool without express written consent from Japzon.

### Enforcement
Unauthorized use or distribution will be met with immediate legal action. We monitor repository forks and clones to ensure intellectual property integrity.

---

## 🚀 Key Features
*   **Parametric Toolkit**: Create precision mechanical and electronic components.
*   **URDF Bridge**: Seamless export to ROS and Gazebo.
*   **Kinematic Suite**: Automated rigging for complex robotic systems.
*   **AI Factory**: Intelligent component generation and placement.

## 🛠 Installation
1.  Download the latest release zip.
2.  In Blender, go to `Edit > Preferences > Add-ons > Install`.
3.  Select the zip file and enable the add-on.

---

**Author**: Japzon  
**Support**: Please open an issue in the tracker for technical assistance.
